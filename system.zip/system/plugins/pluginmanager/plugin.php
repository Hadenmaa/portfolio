<?php
$plugin = array(
	'name' => 'Plugin Manager',
	'description' => 'Tool to enable/disable plugins',
	'admin' => array('menu' => array('Plugin Manager' => 'admin'))
	);
?>