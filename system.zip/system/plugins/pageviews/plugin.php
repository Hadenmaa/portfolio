<?php
$plugin = array(
	'name' => 'Page Views',
	'description' => 'Display the top 10 page views in a pie chart',
	'admin' => array('menu' => array('Page Views' => 'admin'))
	);
?>