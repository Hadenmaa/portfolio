<?php
$plugin = array(
	'name' => 'File Manager',
	'description' => 'Implements a basic file manager',
	'admin' => array('menu' => array('File Manager' => 'adminform'))
	);
?>